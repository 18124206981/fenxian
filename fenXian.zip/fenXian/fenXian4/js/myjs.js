$(function(){
    //初始化动画
    new WOW().init();

    //返回顶部
    $(window).scroll(function () {
        if ($(window).scrollTop() >= 100) {
            $('.actGotop').fadeIn(300);
        } else {
            $('.actGotop').fadeOut(300);
        }
    });
    $('.actGotop').click(function () { $('html,body').animate({ scrollTop: '0px' }, 800); });

    //返回抽奖
   /* $(window).scroll(function () {
        if ($(window).scrollTop() >= 100) {
            $('.goRotate').fadeIn(300);
        } else {
            $('.goRotate').fadeOut(300);
        }
    });*/
    $('.goRotate').click(function () {
        $('html,body').animate({ scrollTop: '950px' }, 800);$('#InfoSuccessModal').modal('hide'); });

   /*抽奖*/
/*    var rotateTimeOut = function (){
        $('#rotate').rotate({
            angle:0,
            animateTo:2160,
            duration:8000,
            callback:function (){
                alert('网络超时，请检查您的网络设置！');
            }
        });
    };
    var bRotate = false;
    var rotateFn = function (awards, angles, txt){
        bRotate = !bRotate;
        $('#rotate').stopRotate();
        $('#rotate').rotate({
            angle:0,
            animateTo:angles+1800,
            duration:8000,
            callback:function (){
                alert("￥"+txt);
                bRotate = !bRotate;
            }
        })
    };
    $('.pointer').click(function (){
        var a=[1,18,16,12,2,8,6];
        if(bRotate)return;

        var item = rnd(0,7);
        //var item =6;
        switch (item) {

            /!*case 0:
                //var angle = [26, 88, 137, 185, 235, 287, 337];
                rotateFn(0, 337, a[0]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[0];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);

                break;
            case 1:
                //var angle = [88, 137, 185, 235, 287];

                rotateFn(1, 26, a[1]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[1];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 2:
                //var angle = [137, 185, 235, 287];
                rotateFn(2, 88, a[2]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[2];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);

                $(".qian2").html(cc);
                break;
            case 3:
                //var angle = [137, 185, 235, 287];
                rotateFn(3, 137, a[3]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[3];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 4:
                //var angle = [185, 235, 287];
                rotateFn(4, 287, a[4]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[4];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 5:

                //var angle = [185, 235, 287];
                rotateFn(5, 185, a[5]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[5];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 6:

                //var angle = [185, 235, 287];
                rotateFn(6, 185, a[6]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[6];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 7:

                //var angle = [185, 235, 287];
                rotateFn(7, 185, a[7]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[7];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;
            case 8:
                //var angle = [235, 287];
                rotateFn(8, 235, a[8]);
                var ss=Number($("#xianjin").val());
                var cc=ss+a[8];
                $("#xianjin").val(cc);
                setTimeout(function(){
                    $(".xianjin").html(cc);
                },8000);
                $(".qian2").html(cc);
                break;*!/
            case 0:
                rotateFn(0, 0, '恭喜您抽中了冲刺书籍！');
                break;
            case 1:
                rotateFn(1, 37.5, '恭喜您抽中了综合课程128课时！');
                break;
            case 2:
                rotateFn(2, 75, '恭喜您抽中了DW 手表！');
                break;
            case 3:
                rotateFn(3, 112, '恭喜您抽中了考前冲刺30课时！');
                break;
            case 4:
                rotateFn(4, 150, '没有抽中很遗憾！');
                setTimeout("SelectUrl()", 11000);
                $('#queding').hide();
                $('#go-select').show();
                break;
            case 5:
                rotateFn(5, 187.5, '恭喜您抽中了高分强化单项课程68课时！');
                break;
            case 6:
                rotateFn(6, 225, '恭喜您抽中了IPad 32G！');
                break;
            case 7:
                rotateFn(7, 262.5, '恭喜您抽中了高分强化单项课程86课时！');
                break;
        }

        //console.log(item);
    });*/

    /* 中奖名单*/
    $(".roll-top").slide({mainCell:".bd ul",autoPlay:true,effect:"topMarquee",vis:5,interTime:50});

    /*雅思考试及报名时间*/
    $('#kaoshiCalendar').calendar({
        trigger: '#kaoshi',
        zIndex: 999,
        format: 'yyyy-mm-dd',
        onSelected: function (view, date, data) {
            console.log('event: onSelected')
        },
        onClose: function (view, date, data) {
            console.log('event: onClose')
            console.log('view:' + view)
            console.log('date:' + date)
            console.log('data:' + (data || 'None'));
        }
    });
    $('#baomingCalendar').calendar({
        trigger: '#baoming',
        zIndex: 999,
        format: 'yyyy-mm-dd',
        onSelected: function (view, date, data) {
            console.log('event: onSelected')
        },
        onClose: function (view, date, data) {
            console.log('event: onClose')
            console.log('view:' + view)
            console.log('date:' + date)
            console.log('data:' + (data || 'None'));
        }
    });
});

